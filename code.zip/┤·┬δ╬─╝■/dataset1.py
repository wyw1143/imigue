import os
import shutil

# 移动并重命名文件
def move_and_rename_files(root_folder):
    # 遍历所有子文件夹
    for subdir, _, files in os.walk(root_folder):
        # 跳过根文件夹本身
        if subdir == root_folder:
            continue
        
        # 提取子文件夹的名称
        folder_name = os.path.basename(subdir)
        
        # 遍历子文件夹中的所有文件
        for file_name in files:
            # 只处理MP4文件
            if file_name.endswith('.mp4'):
                # 获取原文件的完整路径
                old_file_path = os.path.join(subdir, file_name)
                
                # 创建新的文件名，加上子文件夹名称前缀
                new_file_name = f"{folder_name}_{file_name}"
                new_file_path = os.path.join(root_folder, new_file_name)
                
                # 移动并重命名文件
                shutil.move(old_file_path, new_file_path)
                print(f"Moved and renamed: {old_file_path} -> {new_file_path}")

# 使用你的根文件夹路径
root_folder = './IMIGUE2/val/'  # 替换为你的根文件夹路径
move_and_rename_files(root_folder)

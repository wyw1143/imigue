import os
import pickle
import numpy as np

# 定义加载和处理 pkl 文件的路径
pkl_file_path = './IMIGUE2/train.pkl'

# 读取 pkl 文件
with open(pkl_file_path, 'rb') as fr:
    data = pickle.load(fr)

# 遍历annotations进行维度增加操作
for annotation in data['annotations']:
    # 对keypoint增加维度
    annotation['keypoint'] = np.expand_dims(annotation['keypoint'], axis=0)  # 从 [n, 22, 2] 变为 [1, n, 22, 2]
    
    # 对keypoint_score增加维度
    annotation['keypoint_score'] = np.expand_dims(annotation['keypoint_score'], axis=0)  # 从 [n, 22] 变为 [1, n, 22]
# 如果需要，可以将修改后的数据保存到新的 pkl 文件中
modified_pkl_file_path = './IMIGUE2/train2.pkl'
with open(modified_pkl_file_path, 'wb') as fw:
    pickle.dump(data, fw, pickle.HIGHEST_PROTOCOL)

print(f"Modified data has been saved to {modified_pkl_file_path}.")

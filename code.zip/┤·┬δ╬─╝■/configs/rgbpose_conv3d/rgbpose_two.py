# model_cfg
backbone_cfg = dict(
    type='RGBPoseConv3D',
    speed_ratio=4,
    channel_ratio=4,
    rgb_pathway=dict(
        input_resolution=224,
        patch_size=16,
        num_frames=8,
        width=768,
        layers=12,
        heads=12,
        drop_path_rate=0.2,
        adapter_scale=0.5),
    pose_pathway=dict(
        in_channels=22,
        base_channels=32,
        num_stages=3,
        out_indices=(2, ),
        stage_blocks=(4, 6, 3),
        conv1_stride=(1, 1),
        pool1_stride=(1, 1),
        inflate=(0, 1, 1),
        spatial_strides=(2, 2, 2),
        temporal_strides=(1, 1, 2)))
head_cfg = dict(
    type='RGBPoseHead',
    num_classes=32,
    in_channels=512,
    loss_components=['rgb','pose'],
    dropout=0.5,
    loss_weights=[1.,1.])
test_cfg = dict(average_clips='score')
model = dict(
    type='MMRecognizer3D',
    backbone=backbone_cfg,
    cls_head=head_cfg,
    test_cfg=test_cfg)


dataset_type = 'PoseDataset'
train_data_root = './IMIGUE2/train'
train_ann_file = './IMIGUE2/train3.pkl'
val_data_root = './IMIGUE2/val'
val_ann_file = './IMIGUE2/val3.pkl'
test_data_root = './IMIGUE2/test'
test_ann_file = './IMIGUE2/test3.pkl'
left_kp = [1, 3, 5, 7, 9, 11, 13, 15,17,19]
right_kp = [2, 4, 6, 8, 10, 12, 14, 16,18,20]
img_norm_cfg = dict(
    mean=[122.769, 116.74, 104.04], std=[68.493, 66.63, 70.321], to_bgr=False)
train_pipeline = [
    dict(type='MMUniformSampleFrames', clip_len=dict(RGB=8, Pose=48), num_clips=1),
    dict(type='MMDecode'),
    dict(type='PoseCompact', hw_ratio=1., allow_imgpad=True),
    dict(type='Resize', scale=(256, 256), keep_ratio=False),
    dict(type='RandomResizedCrop', area_range=(0.56, 1.0)),
    dict(type='Resize', scale=(224, 224), keep_ratio=False),
    dict(type='Flip', flip_ratio=0.5, left_kp=left_kp, right_kp=right_kp),
    dict(type='GeneratePoseTarget', sigma=0.7, use_score=True, with_kp=True, with_limb=False, scaling=0.25),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='FormatShape', input_format='NCTHW'),
    dict(type='Collect', keys=['imgs', 'heatmap_imgs', 'label','emb'], meta_keys=[]),
    dict(type='ToTensor', keys=['imgs', 'heatmap_imgs', 'label','emb'])
]
val_pipeline = [
    dict(type='MMUniformSampleFrames', clip_len=dict(RGB=8, Pose=48), num_clips=1),
    dict(type='MMDecode'),
    dict(type='PoseCompact', hw_ratio=1., allow_imgpad=True),
    dict(type='Resize', scale=(224, 224), keep_ratio=False),
    dict(type='GeneratePoseTarget', sigma=0.7, use_score=True, with_kp=True, with_limb=False, scaling=0.25),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='FormatShape', input_format='NCTHW'),
    dict(type='Collect', keys=['imgs', 'heatmap_imgs', 'label','emb'], meta_keys=[]),
    dict(type='ToTensor', keys=['imgs', 'heatmap_imgs', 'label','emb'])
]
test_pipeline = [
    dict(type='MMUniformSampleFrames', clip_len=dict(RGB=8, Pose=48), num_clips=10),
    dict(type='MMDecode'),
    dict(type='PoseCompact', hw_ratio=1., allow_imgpad=True),
    dict(type='Resize', scale=(224, 224), keep_ratio=False),
    dict(type='GeneratePoseTarget', sigma=0.7, use_score=True, with_kp=True, with_limb=False, scaling=0.25),
    dict(type='Normalize', **img_norm_cfg),
    dict(type='FormatShape', input_format='NCTHW'),
    dict(type='Collect', keys=['imgs', 'heatmap_imgs', 'label','emb'], meta_keys=[]),
    dict(type='ToTensor', keys=['imgs', 'heatmap_imgs', 'label','emb'])
]

data = dict(
    videos_per_gpu=8,
    workers_per_gpu=4,
    val_dataloader=dict(videos_per_gpu=1),
    test_dataloader=dict(videos_per_gpu=1),
    train=dict(
        type='RepeatDataset',
        times=1,
        dataset=dict(type=dataset_type, split='train', ann_file=train_ann_file, data_prefix=train_data_root, pipeline=train_pipeline)),
        val=dict(type=dataset_type, ann_file=val_ann_file, split='val', data_prefix=val_data_root, pipeline=val_pipeline),
    test=dict(type=dataset_type, ann_file=test_ann_file, split='test', data_prefix=test_data_root, pipeline=test_pipeline))
# optimizer

# learning policy
optimizer = dict(type='AdamW', lr=3.3e-6, betas=(0.9, 0.999), weight_decay=0.03)
optimizer_config = dict(grad_clip=dict(max_norm=40, norm_type=2))
lr_config = dict(policy='CosineAnnealing', by_epoch=False, min_lr=0)

total_epochs = 10
checkpoint_config = dict(interval=1)
workflow = [('train', 1)]
evaluation = dict(interval=1, metrics=['top_k_accuracy', 'mean_class_accuracy'], topk=(1, 5), key_indicator='RGBPose_1:1_top1_acc')
log_config = dict(interval=20, hooks=[dict(type='TextLoggerHook')])
work_dir = './work_dirs_adapter/'
load_from = 'rgbpose5.pth'

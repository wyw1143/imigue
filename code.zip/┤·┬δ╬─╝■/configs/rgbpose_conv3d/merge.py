import torch

# 从本地文件加载预训练模型的 state_dict
model_path = 'filtered_model.pth'
state_dict = torch.load(model_path)['state_dict']

# 创建一个新的字典，保存以 'backbone.model.' 开头的权重
filtered_state_dict = {k: v for k, v in state_dict.items()}

# 遍历并打印过滤后的权重
for name, param in filtered_state_dict.items():
    print(f"Name: {name}, Shape: {param.shape}")

# 将过滤后的 state_dict 保存到一个新的文件
#torch.save({'state_dict': filtered_state_dict}, 'filtered_model.pth')

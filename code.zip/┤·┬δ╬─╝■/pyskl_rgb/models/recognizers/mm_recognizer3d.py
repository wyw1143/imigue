from ..builder import RECOGNIZERS
from .base import BaseRecognizer
from torch.nn import functional as F

import torch.nn as nn
import torch
import numpy as np
def min_max_normalize(data):
    min_val = min(data)
    max_val = max(data)
    normalized_data = [(x - min_val) / (max_val - min_val) for x in data]
    return normalized_data

@RECOGNIZERS.register_module()
class MMRecognizer3D(BaseRecognizer):
    """MultiModality 3D recognizer model framework."""

    def forward_train(self, imgs, heatmap_imgs, emb, label, **kwargs):

        """Defines the computation performed at every call when training."""
        assert not hasattr(self, 'neck')
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        heatmap_imgs = heatmap_imgs.reshape((-1, ) + heatmap_imgs.shape[2:])
        print(imgs.shape,heatmap_imgs.shape)
        losses = dict()
        preds = self.extract_feat(imgs, heatmap_imgs,training=True)


        gt_label = label.squeeze()
        
        loss_cls = self.cls_head.loss(preds,gt_label, **kwargs)

        
        losses.update(loss_cls)

        return losses

    def forward_test(self, imgs, heatmap_imgs, emb, **kwargs):

        batches = imgs.shape[0]
        num_segs = imgs.shape[1]
        """Defines the computation performed at every call when evaluation and
        testing."""
        assert imgs.shape[0] == 1 and heatmap_imgs.shape[0] == 1
        assert not hasattr(self, 'neck')
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        heatmap_imgs = heatmap_imgs.reshape((-1, ) + heatmap_imgs.shape[2:])
        preds = self.extract_feat(imgs, heatmap_imgs,training=False)
        #cls_score,emb_score  = self.cls_head(x_pose)
        cls_score = preds.reshape(batches, num_segs, preds.shape[-1])
        cls_score = self.average_clip(cls_score)
        return cls_score.cpu().numpy()

        

    def forward(self, imgs, heatmap_imgs, emb = None, label=None, return_loss=True, **kwargs):
        """Define the computation performed at every call."""

        if return_loss:
            if label is None:
                raise ValueError('Label should not be None.')
            return self.forward_train(imgs, heatmap_imgs, emb, label, **kwargs)

        return self.forward_test(imgs, heatmap_imgs, emb, **kwargs)

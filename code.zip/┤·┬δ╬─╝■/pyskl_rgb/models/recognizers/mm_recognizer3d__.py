from ..builder import RECOGNIZERS
from .base import BaseRecognizer
from torch.nn import functional as F

import torch.nn as nn
import torch
import numpy as np
def min_max_normalize(data):
    min_val = min(data)
    max_val = max(data)
    normalized_data = [(x - min_val) / (max_val - min_val) for x in data]
    return normalized_data

@RECOGNIZERS.register_module()
class MMRecognizer3D(BaseRecognizer):
    """MultiModality 3D recognizer model framework."""

    def forward_train(self, imgs, heatmap_imgs, emb, label, **kwargs):

        """Defines the computation performed at every call when training."""
        assert not hasattr(self, 'neck')
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        heatmap_imgs = heatmap_imgs.reshape((-1, ) + heatmap_imgs.shape[2:])
        losses = dict()
        x_rgb, x_pose = self.backbone(imgs, heatmap_imgs, training = True)

        cls_scores,emb_score = self.cls_head(x_rgb, x_pose)

        gt_label = label.squeeze()
        #loss_cls = self.cls_head.loss(preds, gt_label, **kwargs)

        loss_components = self.cls_head.loss_components
        loss_weights = self.cls_head.loss_weights
        for loss_name, weight in zip(loss_components, loss_weights):
            cls_score = cls_scores[loss_name]
            loss_cls = self.cls_head.loss(loss_name, cls_score, emb_score, gt_label, emb)
            loss_cls = {loss_name + '_' + k: v for k, v in loss_cls.items()}
            loss_cls[f'{loss_name}_loss_cls'] *= weight
            losses.update(loss_cls)


        
        #loss_cls_value = loss_cls['loss_cls']  # 提取损失值

        #icl_loss = (F.cross_entropy(icl, gt_label) + F.cross_entropy(icl2, gt_label)) / 2
        #distillation_loss_1 = (img_encode - raw_img_encode).norm(p=2, dim=-1).mean()
        #distillation_loss_2 = (text_encode - raw_text_encode).norm(p=2, dim=-1).mean()
        # 将其与 distillation_loss_1 相加
        #distillation_loss = (distillation_loss_1 + distillation_loss_2) *2
        #loss_cls_value = loss_cls_value + distillation_loss + icl_loss
        # 然后可以将它重新存回字典（如果需要）
        #loss_cls['loss_cls'] = loss_cls_value
        #losses.update(loss_cls)
        #loss_components = self.cls_head.loss_components
        #loss_weights = self.cls_head.loss_weights
        #for loss_name, weight in zip(loss_components, loss_weights):
        #    cls_score = cls_scores[loss_name]
        #    loss_cls = self.cls_head.loss(loss_name, cls_score, emb_score, gt_label, text_encode)
        #    loss_cls = {loss_name + '_' + k: v for k, v in loss_cls.items()}
        #    loss_cls[f'{loss_name}_loss_cls'] *= weight
        return losses

    def forward_test(self, imgs, heatmap_imgs, emb, **kwargs):
        batches = imgs.shape[0]
        num_segs = imgs.shape[1]
        """Defines the computation performed at every call when evaluation and
        testing."""
        assert imgs.shape[0] == 1 and heatmap_imgs.shape[0] == 1
        assert not hasattr(self, 'neck')
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        heatmap_imgs = heatmap_imgs.reshape((-1, ) + heatmap_imgs.shape[2:])
        x_rgb, x_pose = self.backbone(imgs, heatmap_imgs, training = True)
        cls_scores,emb_score = self.cls_head(x_pose, x_rgb)



        #preds = x_rgb
        for k in cls_scores:
            cls_score = self.average_clip(cls_scores[k][None])
            cls_scores[k] = cls_score.data.cpu().numpy()[0]
        #cls_score = x_rgb.reshape(batches, num_segs, x_rgb.shape[-1])
        #cls_score = self.average_clip(cls_score)
        return [cls_scores]
        #cls_scores,emb_score = self.cls_head(x_ske_feat)


        #for k in cls_scores:
        #    cls_score = self.average_clip(cls_scores[k][None])
        #    cls_scores[k] = cls_score.data.cpu().numpy()[0]
        return cls_score.cpu().numpy()
        

    def forward(self, imgs, heatmap_imgs, emb = None, label=None, return_loss=True, **kwargs):
        """Define the computation performed at every call."""

        if return_loss:
            if label is None:
                raise ValueError('Label should not be None.')
            return self.forward_train(imgs, heatmap_imgs, emb, label, **kwargs)

        return self.forward_test(imgs, heatmap_imgs, emb, **kwargs)

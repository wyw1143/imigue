from collections import OrderedDict
from typing import Tuple, Union
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from torch import nn, einsum

import torch
from torch.utils.checkpoint import checkpoint_sequential
from . import clip
from .clip.model import LayerNorm, QuickGELU
from .torch_utils import activation
from einops import rearrange, repeat
from einops.layers.torch import Rearrange



class Adapter(nn.Module):
    def __init__(self, D_features, mlp_ratio=0.25, act_layer=nn.GELU, skip_connect=True):
        super().__init__()
        self.skip_connect = skip_connect
        D_hidden_features = int(D_features * mlp_ratio)
        self.act = act_layer()
        self.D_fc1 = nn.Linear(D_features, D_hidden_features)
        self.D_fc2 = nn.Linear(D_hidden_features, D_features)
        
    def forward(self, x):
        # x is (BT, HW+1, D)
        xs = self.D_fc1(x)
        xs = self.act(xs)
        xs = self.D_fc2(xs)
        if self.skip_connect:
            x = x + xs
        else:
            x = xs
        return x


# TYPE 1: expand temporal attention view
class TimesAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, temporal_modeling_type='expand_temporal_view'):
        super().__init__()
        self.T = T
        
        # type: channel_shift or expand_temporal_view
        self.attn = activation.MultiheadAttention(d_model, n_head, temporal_shift=temporal_modeling_type, T=T)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))

        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        l, bt, d = x.size()
        #197,32,768
        b = bt // self.T
        # x = x.view(l, b, self.T, d)
        x = x + self.attention(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
         
        return x

# Type 2: temporal shift, same as space-time mixing paper
class ChannelShiftAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, ):
        super().__init__()
        self.T = T
        
        # type: channel_shift or expand_temporal_view
        self.attn = activation.MultiheadAttention(d_model, n_head, temporal_shift='channel_shift')
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))
        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        l, bt, d = x.size()
        b = bt // self.T
        # x = x.view(l, b, self.T, d)
        x = x + self.attention(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
         
        return x

# TYPE 3: additional parameter, do temporal cls tokens attention
class CrossFramelAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, num_experts=0, record_routing=False):
        super().__init__()
        self.T = T
        
        self.message_fc = nn.Linear(d_model, d_model)
        self.message_ln = LayerNorm(d_model)
        self.message_attn = nn.MultiheadAttention(d_model, n_head,)

        self.attn = nn.MultiheadAttention(d_model, n_head,)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))
        self.num_experts = num_experts
        self.record_routing = record_routing
        if num_experts > 0:
            self.experts_head = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_fc", nn.Linear(d_model, d_model * 4)),
                ("gelu", QuickGELU()),
            ])) for _ in range(num_experts)])
            
            self.experts_tail = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_proj", nn.Linear(d_model * 4, d_model))
                ])) for _ in range(num_experts)])

            self.routing1 = nn.Linear(d_model, self.num_experts + 1)
            self.routing2 = nn.Linear(d_model*4, self.num_experts + 1)

        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        if type(x) == tuple:
            x, routing_state = x
        else:
            routing_state = None

        l, bt, d = x.size()
        b = bt // self.T
        x = x.view(l, b, self.T, d)

        msg_token = self.message_fc(x[0,:,:,:])
        msg_token = msg_token.view(b, self.T, 1, d)

        msg_token = msg_token.permute(1,2,0,3).view(self.T, b, d)
        msg_token = msg_token + self.message_attn(self.message_ln(msg_token),self.message_ln(msg_token),self.message_ln(msg_token),need_weights=False)[0]
        msg_token = msg_token.view(self.T, 1, b, d).permute(1,2,0,3)

        x = torch.cat([x, msg_token], dim=0)

        x = x.view(l+1, -1, d)
        x = x + self.attention(self.ln_1(x))
        x = x[:l,:,:]

        ln_x = self.ln_2(x)
        # x = x + self.mlp(self.ln_2(x))
        if self.num_experts > 0:
            output_head = [self.mlp[0](ln_x)]
            [output_head.append(self.experts_head[i][0](ln_x)) for i in range(self.num_experts)]
            rout1 = torch.nn.functional.softmax(self.routing1(ln_x), -1).unsqueeze(-1)
            output_head = torch.stack(output_head, 0).permute(1,2,0,3)
            output_head = (rout1 * output_head).sum(-2)
            output_head = self.mlp[1](output_head)

            output = [self.mlp[2](output_head)]
            [output.append(self.experts_tail[i](output_head)) for i in range(self.num_experts)]
            rout2 = torch.nn.functional.softmax(self.routing2(output_head), -1).unsqueeze(-1)
            output = torch.stack(output, 0).permute(1,2,0,3)
            output = (rout2 * output).sum(-2)
        else:
            output = self.mlp(ln_x)
        
        x = x + output
        
        if self.record_routing:
            if self.num_experts > 0:
                current_rout = torch.stack([rout1.squeeze(-1), rout2.squeeze(-1)], 0)
                if routing_state == None:
                    routing_state = current_rout
                else:
                    routing_state = torch.cat([routing_state, current_rout], 0)

            return x, routing_state

        return x

# TYPE 4: additional parameter, STadapter
class STAdaptAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, ):
        super().__init__()
        self.T = T
         
        # self.stadapt_down_1 = nn.Conv3d(d_model, d_model//2, kernel_size=(1,1,1),
        #         padding='same', groups=1,)
        # self.stadapt_up_1 = nn.Conv3d(d_model//2, d_model, kernel_size=(1,1,1),
        #         padding='same', groups=1,)
        # self.stadapt_conv3d_1 = nn.Conv3d(d_model//2, d_model//2, kernel_size=(3,1,1),
        #         padding='same', groups=d_model//2,)
        self.stadapt_down_1 = nn.Conv2d(d_model, d_model//2, kernel_size=(1,1),
                padding='same', groups=1,)
        self.stadapt_up_1 = nn.Conv2d(d_model//2, d_model, kernel_size=(1,1),
                padding='same', groups=1,)
        self.stadapt_conv3d_1 = nn.Conv2d(d_model//2, d_model//2, kernel_size=(3,1),
                padding=(1,0), groups=d_model//2,)
        
        self.attn = nn.MultiheadAttention(d_model, n_head,)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))
        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        l, bt, d = x.size()
        b = bt // self.T
        
        x = x.view(l, b, self.T, d)
        cls_token = x[0:1,:,:,:]
        x_img = x[1:, :, :, :]
        x_raw = x_img
        # x_img (l, b, T, d) -> (b, d, T, h, w) 
        h = int(torch.tensor(x_img.shape[0]).sqrt())
        w = int(torch.tensor(x_img.shape[0]).sqrt())
        assert h*w == x_img.shape[0]
        x_img = x_img.permute(1, 3, 2, 0).view(b, d, self.T, h, w)
        # down - conv3d - up
        
        x_img = self.stadapt_up_1(self.stadapt_conv3d_1(self.stadapt_down_1(x_img)))
        x_img = x_img.view(b,d,self.T,h*w).permute(3, 0, 2, 1)
        x_img = x_raw + x_img
        
        x = torch.cat([cls_token, x_img], dim=0)
         
        x = x.view(l, -1, d)
        x = x + self.attention(self.ln_1(x))
        x = x[:l,:,:]
        x = x + self.mlp(self.ln_2(x))
        return x
    
class AIM_Adapter(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        hidden_dim = d_model//4
        self.adapter = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, d_model)
        )

        nn.init.constant_(self.adapter[2].weight, 0)
        nn.init.constant_(self.adapter[2].bias, 0)
    
    def forward(self, x, residual=False):
        x_raw = x
        x = self.adapter(x)
        if residual:
            x = x + x_raw
        return x

class AdapterFormer(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, num_experts=0, record_routing=False):
        super().__init__()
        self.T = T
        self.gelu = nn.GELU()

        self.ffn_adapter = AIM_Adapter(d_model)
 
        self.attn = nn.MultiheadAttention(d_model, n_head)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))

        self.num_experts = num_experts
        self.record_routing = record_routing
        if num_experts > 0:
            self.experts_head = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_fc", nn.Linear(d_model, d_model * 4)),
                ("gelu", QuickGELU()),
            ])) for _ in range(num_experts)])

            self.experts_tail = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_proj", nn.Linear(d_model * 4, d_model))
                ])) for _ in range(num_experts)])
            
            self.routing1 = nn.Linear(d_model, self.num_experts + 1)
            self.routing2 = nn.Linear(d_model*4, self.num_experts + 1)

        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        if type(x) == tuple:
            x, routing_state = x
        else:
            routing_state = None

        l, bt, d = x.size()
        b = bt // self.T

        x = x + self.attention(self.ln_1(x))
        
        ln_x = self.ln_2(x)
        # x = x + self.mlp(self.ln_2(x))
        if self.num_experts > 0:
            output_head = [self.mlp[0](ln_x)]
            [output_head.append(self.experts_head[i][0](ln_x)) for i in range(self.num_experts)]
            rout1 = torch.nn.functional.softmax(self.routing1(ln_x), -1).unsqueeze(-1)
            output_head = torch.stack(output_head, 0).permute(1,2,0,3)
            output_head = (rout1 * output_head).sum(-2)
            output_head = self.mlp[1](output_head)

            output = [self.mlp[2](output_head)]
            [output.append(self.experts_tail[i](output_head)) for i in range(self.num_experts)]
            rout2 = torch.nn.functional.softmax(self.routing2(output_head), -1).unsqueeze(-1)
            output = torch.stack(output, 0).permute(1,2,0,3)
            output = (rout2 * output).sum(-2)
        else:
            output = self.mlp(ln_x) + self.ffn_adapter(ln_x) * 0.5

        x = x + output

        if self.record_routing:
            if self.num_experts > 0:
                current_rout = torch.stack([rout1.squeeze(-1), rout2.squeeze(-1)], 0)
                if routing_state == None:
                    routing_state = current_rout
                else:
                    routing_state = torch.cat([routing_state, current_rout], 0)

            return x, routing_state

        return x

class AIM(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, num_experts=0, record_routing=False):
        super().__init__()
        self.T = T
        self.gelu = nn.GELU()

        self.t_adapter = AIM_Adapter(d_model)
        self.s_adapter = AIM_Adapter(d_model)
        self.ffn_adapter = AIM_Adapter(d_model)
 
        self.attn = nn.MultiheadAttention(d_model, n_head)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))

        self.num_experts = num_experts
        self.record_routing = record_routing
        if num_experts > 0:
            self.experts_head = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_fc", nn.Linear(d_model, d_model * 4)),
                ("gelu", QuickGELU()),
            ])) for _ in range(num_experts)])

            self.experts_tail = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_proj", nn.Linear(d_model * 4, d_model))
                ])) for _ in range(num_experts)])
            
            self.routing1 = nn.Linear(d_model, self.num_experts + 1)
            self.routing2 = nn.Linear(d_model*4, self.num_experts + 1)

        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        if type(x) == tuple:
            x, routing_state = x
        else:
            routing_state = None

        l, bt, d = x.size()
        b = bt // self.T
        x = x.view(l, b, self.T, d).permute(2, 1, 0, 3).contiguous().view(self.T, b*l, d)
        x = x + self.t_adapter(self.attention(self.ln_1(x)))

        x = x.view(self.T, b, l, d).permute(2, 1, 0, 3).contiguous().view(l, b*self.T, d)
        x = x + self.s_adapter(self.attention(self.ln_1(x)), residual=True)
        
        ln_x = self.ln_2(x)
        
        if self.num_experts > 0:
            output_head = [self.mlp[0](ln_x)]
            [output_head.append(self.experts_head[i][0](ln_x)) for i in range(self.num_experts)]
            rout1 = torch.nn.functional.softmax(self.routing1(ln_x), -1).unsqueeze(-1)
            output_head = torch.stack(output_head, 0).permute(1,2,0,3)
            output_head = (rout1 * output_head).sum(-2)
            output_head = self.mlp[1](output_head)

            output = [self.mlp[2](output_head)]
            [output.append(self.experts_tail[i](output_head)) for i in range(self.num_experts)]
            rout2 = torch.nn.functional.softmax(self.routing2(output_head), -1).unsqueeze(-1)
            output = torch.stack(output, 0).permute(1,2,0,3)
            output = (rout2 * output).sum(-2)
        else:
            output = self.mlp(ln_x) + self.ffn_adapter(ln_x) * 0.5

        x = x + output

        if self.record_routing:
            if self.num_experts > 0:
                current_rout = torch.stack([rout1.squeeze(-1), rout2.squeeze(-1)], 0)
                if routing_state == None:
                    routing_state = current_rout
                else:
                    routing_state = torch.cat([routing_state, current_rout], 0)

            return x, routing_state

        return x

# TYPE 5: additional parameter, STadapter, with zero initialization
class STAdaptZeroInitAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, num_experts=0, record_routing=False):
        super().__init__()
        self.T = T
         
        self.stadapt_down_1 = nn.Conv2d(d_model, d_model//2, kernel_size=(1,1),
                padding='same', groups=1,)
        self.stadapt_up_1 = nn.Conv2d(d_model//2, d_model, kernel_size=(1,1),
                padding='same', groups=1,)
        self.stadapt_conv3d_1 = nn.Conv2d(d_model//2, d_model//2, kernel_size=(3,1),
                padding='same', groups=d_model//2,)
        # self.stadapt_down_1 = nn.Conv3d(d_model, d_model//2, kernel_size=(1,1,1),
        #         padding='same', groups=1,)
        # self.stadapt_up_1 = nn.Conv3d(d_model//2, d_model, kernel_size=(1,1,1),
        #         padding='same', groups=1,)
        # self.stadapt_conv3d_1 = nn.Conv3d(d_model//2, d_model//2, kernel_size=(3,1,1),
        #         padding='same', groups=d_model//2,)
        
        nn.init.constant_(self.stadapt_up_1.weight, 0)
        nn.init.constant_(self.stadapt_up_1.bias, 0)
 
        self.attn = nn.MultiheadAttention(d_model, n_head,)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))
        self.num_experts = num_experts
        self.record_routing = record_routing
        if num_experts > 0:
            self.experts_head = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_fc", nn.Linear(d_model, d_model * 4)),
                ("gelu", QuickGELU()),
            ])) for _ in range(num_experts)])

            self.experts_tail = nn.Sequential(*[nn.Sequential(OrderedDict([
                ("c_proj", nn.Linear(d_model * 4, d_model))
                ])) for _ in range(num_experts)])
            
            self.routing1 = nn.Linear(d_model, self.num_experts + 1)
            self.routing2 = nn.Linear(d_model*4, self.num_experts + 1)

        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        if type(x) == tuple:
            x, routing_state = x
        else:
            routing_state = None

        l, bt, d = x.size()
        b = bt // self.T
        
        x = x.view(l, b, self.T, d)
        cls_token = x[0:1,:,:,:]
        x_img = x[1:, :, :, :]
        x_raw = x_img
        # x_img (l, b, T, d) -> (b*l, d, T, 1) 
        h = int(torch.tensor(x_img.shape[0]).sqrt())
        w = int(torch.tensor(x_img.shape[0]).sqrt())
        assert h*w == x_img.shape[0]
        x_img = x_img.permute(1, 0, 3, 2).contiguous().view(b*h*w, d, self.T, 1)
        # down - conv3d - up
        x_img = self.stadapt_up_1(self.stadapt_conv3d_1(self.stadapt_down_1(x_img)))
        x_img = x_img.view(b, h*w, d, self.T).permute(1, 0, 3, 2).contiguous()

        x_img = x_raw + x_img
        
        x = torch.cat([cls_token, x_img], dim=0)
         
        x = x.view(l, -1, d)
        x = x + self.attention(self.ln_1(x))
        x = x[:l,:,:]
        
        ln_x = self.ln_2(x)
        # x = x + self.mlp(self.ln_2(x))
        if self.num_experts > 0:
            output_head = [self.mlp[0](ln_x)]
            [output_head.append(self.experts_head[i][0](ln_x)) for i in range(self.num_experts)]
            rout1 = torch.nn.functional.softmax(self.routing1(ln_x), -1).unsqueeze(-1)
            output_head = torch.stack(output_head, 0).permute(1,2,0,3)
            output_head = (rout1 * output_head).sum(-2)
            output_head = self.mlp[1](output_head)

            output = [self.mlp[2](output_head)]
            [output.append(self.experts_tail[i](output_head)) for i in range(self.num_experts)]
            rout2 = torch.nn.functional.softmax(self.routing2(output_head), -1).unsqueeze(-1)
            output = torch.stack(output, 0).permute(1,2,0,3)
            output = (rout2 * output).sum(-2)
        else:
            output = self.mlp(ln_x)

        x = x + output

        if self.record_routing:
            if self.num_experts > 0:
                current_rout = torch.stack([rout1.squeeze(-1), rout2.squeeze(-1)], 0)
                if routing_state == None:
                    routing_state = current_rout
                else:
                    routing_state = torch.cat([routing_state, current_rout], 0)

            return x, routing_state

        return x


class ResidualAttentionBlock(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, scale=1., num_tadapter=1, num_frames=8, drop_path=0.):
        super().__init__()
        self.num_tadapter = num_tadapter
        self.attn = nn.MultiheadAttention(d_model, n_head)
        self.ln_1 = LayerNorm(d_model)
        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))
        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask
        self.n_head = n_head

        self.MLP_Adapter = Adapter(d_model, skip_connect=False)
        self.S_Adapter = Adapter(d_model)
        self.scale = scale
        self.T_Adapter = Adapter(d_model, skip_connect=False)
        if num_tadapter == 2:
            self.T_Adapter_in = Adapter(d_model)
        self.num_frames = num_frames
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x: torch.Tensor):
        ## x shape [HW+1, BT, D]
        n, bt, d = x.shape
        ## temporal adaptation
        xt = rearrange(x, 'n (b t) d -> t (b n) d', t=self.num_frames)
        if self.num_tadapter == 2:
            xt = self.T_Adapter(self.attention(self.T_Adapter_in(self.ln_1(xt))))
        else:
            xt = self.T_Adapter(self.attention(self.ln_1(xt)))
        xt = rearrange(xt, 't (b n) d -> n (b t) d', n=n)
        x = x + self.drop_path(xt)
        ## spatial adaptation
        x = x + self.S_Adapter(self.attention(self.ln_1(x)))
        ## joint adaptation
        xn = self.ln_2(x)
        x = x + self.mlp(xn) + self.drop_path(self.scale * self.MLP_Adapter(xn))
        return x

# ORIGIN
class Transformer(nn.Module):
    def __init__(self, width: int, layers: int, heads: int, attn_mask: torch.Tensor = None):
        super().__init__()
        self.width = width
        self.layers = layers
        self.resblocks = nn.Sequential(*[ResidualAttentionBlock(width, heads, attn_mask) for _ in range(layers)])

    def forward(self, x: torch.Tensor):
        return self.resblocks(x)

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn
    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )
    def forward(self, x):
        return self.net(x)


# TYPE
class TSTransformer(nn.Module):
    def __init__(self, width: int, layers: int, heads: int, attn_mask: torch.Tensor = None, use_checkpoint=False, T=8, temporal_modeling_type=None, num_experts=0, expert_insert_layers=[], record_routing=False, routing_type='patch-level'):
        super().__init__()
        self.use_checkpoint = use_checkpoint
        self.width = width
        self.layers = layers
        self.use_checkpoint = use_checkpoint
        self.T = T
        self.temporal_modeling_type = temporal_modeling_type
        self.record_routing = record_routing
        self.routing_type = routing_type

        if self.temporal_modeling_type == None:
            self.resblocks = nn.Sequential(*[ResidualAttentionBlock(width, heads, attn_mask, num_experts, record_routing, routing_type) if layer_id in expert_insert_layers else ResidualAttentionBlock(width, heads, attn_mask, record_routing=record_routing, routing_type=routing_type) for layer_id in range(layers)])
        elif self.temporal_modeling_type == 'expand_temporal_view' or self.temporal_modeling_type == 'expand_temporal_view_step2' or self.temporal_modeling_type == 'expand_temporal_view_step3':
            self.resblocks = nn.Sequential(*[TimesAttentionBlock(width, heads, attn_mask, T=T, temporal_modeling_type=self.temporal_modeling_type) for _ in range(layers)])
            # TimesAttentionBlock
        elif self.temporal_modeling_type == 'channel_shift':
            self.resblocks = nn.Sequential(*[ChannelShiftAttentionBlock(width, heads, attn_mask, T=T) for _ in range(layers)])
            # ChannelShiftAttentionBlock
        elif self.temporal_modeling_type == 'cross_frame_attend':
            self.resblocks = nn.Sequential(*[CrossFramelAttentionBlock(width, heads, attn_mask, T=T, num_experts=num_experts, record_routing=record_routing) if layer_id in expert_insert_layers else CrossFramelAttentionBlock(width, heads, attn_mask, T=T, record_routing=record_routing) for layer_id in range(layers)])
            # CrossFramelAttentionBlock
        elif self.temporal_modeling_type == 'stadapt_zeroinit':
            self.resblocks = nn.Sequential(*[STAdaptZeroInitAttentionBlock(width, heads, attn_mask, T=T, num_experts=num_experts, record_routing=record_routing) if layer_id in expert_insert_layers else STAdaptZeroInitAttentionBlock(width, heads, attn_mask, T=T, record_routing=record_routing) for layer_id in range(layers)])
            # STAdapter
        elif self.temporal_modeling_type == 'aim':
            self.resblocks = nn.Sequential(*[AIM(width, heads, attn_mask, T=T, num_experts=num_experts, record_routing=record_routing) if layer_id in expert_insert_layers else AIM(width, heads, attn_mask, T=T, record_routing=record_routing) for layer_id in range(layers)])
        elif self.temporal_modeling_type == 'adapter':
            self.resblocks = nn.Sequential(*[AdapterFormer(width, heads, attn_mask, T=T, num_experts=num_experts, record_routing=record_routing) if layer_id in expert_insert_layers else AdapterFormer(width, heads, attn_mask, T=T, record_routing=record_routing) for layer_id in range(layers)])
        else:
            raise NotImplementedError

        # self.resblocks = nn.Sequential(*[TimesAttentionBlock(width, heads, attn_mask, T) for i in range(layers)])

    def forward(self, x, prompt_token=None):
        #print('x00 shape is',x.shape)
        if not self.use_checkpoint:
            if not self.record_routing:
                # return self.resblocks(x)
                for block in self.resblocks:
                    x = block(x)
                    l, b, c = x.size()
                    if prompt_token is not None:
                        x[-1, :, :] = x[-1, :, :] + prompt_token.view(b, c)
                return x
            else:
                # return self.resblocks(x)
                for block in self.resblocks:
                    x = block(x)
                    l, b, c = x.size()
                    if prompt_token is not None:
                        x[-1, :, :] = x[-1, :, :] + prompt_token.view(b, c)
                return x
                """
                for layer_id, resblock in enumerate(self.resblocks):
                    middle_output = resblock(x)
                    if type(middle_output) == tuple and len(middle_output) == 3:
                        x, rout1, rout2 = middle_output
                        routing_state.append(rout1)
                        routing_state.append(rout2)
                    else:
                        x = middle_output

                routing_state = torch.stack(routing_state, 0) 
                return x, routing_state
                """
        else:
            return checkpoint_sequential(self.resblocks, 3, x)

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn
    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )
    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads, dim_head, dropout = 0.):
        super().__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        #[32, 197, 768])，4，9，768
        b, n, _, h = *x.shape, self.heads
        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = h), qkv)

        dots = einsum('b h i d, b h j d -> b h i j', q, k) * self.scale

        attn = dots.softmax(dim=-1)

        out = einsum('b h i j, b h j d -> b h i d', attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        out =  self.to_out(out)
        return out
        
class TemTransformer(nn.Module):
    def __init__(self, dim, depth, heads):
        # dim, depth, heads, dim_head, dim*scale_dim
        # dim=768, depth=4, heads=12, dim_head=, dim*scale_dim=dim*4
        super().__init__()
        self.layers = nn.ModuleList([])
        self.norm = nn.LayerNorm(dim)
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                PreNorm(dim, Attention(dim, heads=heads, dim_head=64)),
                PreNorm(dim, FeedForward(dim, 512, dropout=0.))
            ]))

    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return self.norm(x)

# TYPE
class TemporalVisionTransformer(nn.Module):
    def __init__(self, input_resolution: int, patch_size: int, width: int, layers: int, heads: int, output_dim: int, T = 8, temporal_modeling_type = None, use_checkpoint = False, num_experts=0, expert_insert_layers=[], record_routing=False, routing_type='patch-level'):
        super().__init__()
        self.input_resolution = input_resolution
        self.output_dim = output_dim
        self.temporal_modeling_type = temporal_modeling_type
        self.T = T
        self.use_checkpoint = use_checkpoint
        self.record_routing = record_routing
        self.routing_type = routing_type

        self.conv1 = nn.Conv2d(in_channels=3, out_channels=width, kernel_size=patch_size, stride=patch_size, bias=False)

        scale = width ** -0.5
        self.class_embedding = nn.Parameter(scale * torch.randn(width))
        self.positional_embedding = nn.Parameter(scale * torch.randn((input_resolution // patch_size) ** 2 + 1, width))
        self.ln_pre = LayerNorm(width)
        self.temporal_embedding = nn.Parameter(torch.zeros(1, T, width))

        self.temporal_token = nn.Parameter(torch.randn(1, 1, width))


        self.transformer = TSTransformer(width, layers, heads, use_checkpoint=self.use_checkpoint, T=self.T, temporal_modeling_type=self.temporal_modeling_type, num_experts=num_experts, expert_insert_layers=expert_insert_layers, record_routing=record_routing, routing_type=routing_type)
        #self.transformer2 =TemTransformer(width, layers, heads)

        self.ln_post = LayerNorm(width)
        self.proj = nn.Parameter(scale * torch.randn(width, output_dim))
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(width),
            nn.Linear(width, output_dim)
        )

    def forward(self, x):
        x, [maskf, mask] = x
        device = torch.device("cuda:0")

        # 将输入张量 x 移动到指定设备
        B, C, T, H, W = x.shape#2,3,8,224,224
        #x = x.permute(0, 2, 1, 3, 4)
        #x = x.reshape(B * T, C, H, W)
        x = rearrange(x, 'b c t h w -> (b t) c h w')
        x = x.to(device)
        #print('x shape',x.shape)32,3,224,224
        x = self.conv1(x)  # shape = [*, width, grid, grid]
        x = x.reshape(x.shape[0], x.shape[1], -1)  # shape = [*, width, grid ** 2]
        x = x.permute(0, 2, 1).contiguous()  # shape = [*, grid ** 2, width] # (bxt) l c
        #, l, c = x.shape
        #32,196,768

        #b = B // self.T
        #4

        cls_token = self.class_embedding.to(x.dtype) + torch.zeros(x.shape[0], 1, x.shape[-1], dtype=x.dtype, device=x.device)
        #32,1,768
        x = torch.cat([cls_token, x], dim=1)  # shape = [*, grid ** 2 + 1, width]
        x = x + self.positional_embedding.to(x.dtype)
        n = x.shape[1]
        x = rearrange(x, '(b t) n d -> (b n) t d', t=self.num_frames)
        x = x + self.temporal_embedding
        x = rearrange(x, '(b n) t d -> (b t) n d', n=n)
        x = self.ln_pre(x)
        #32,197,768

        x = x.permute(1, 0, 2)  # NLD -> LND
        #197,32,768


        
        if self.record_routing:
            x, routing_state = self.transformer(x)
        else:
            x = self.transformer(x)
            #197,32,768
        
        feature = x.permute(1, 0, 2)  # LND -> NLD
        #x = x.permute(1, 0, 2)

        x = self.ln_post(feature[:, 0, :])
        x = rearrange(x, '(b t) d -> b d t',b=B,t=T)
        
        x = x.unsqueeze(-1).unsqueeze(-1)
        #print('x shape is',x.shape)#[32,768]

        if self.proj is not None:
            x = x @ self.proj
        #print('x2 shape is',x.shape)#[32,512]

        
        if self.record_routing:
            return [x, feature], routing_state
        else:
            return [x, feature]

import os

# 遍历文件夹，修改文件名
def rename_files(root_folder):
    for subdir, _, files in os.walk(root_folder):
        for file_name in files:
            # 只处理MP4文件
            if file_name.endswith('.mp4'):
                # 拆分文件名，获取 _ 后的数字部分
                base_name, ext = os.path.splitext(file_name)
                parts = base_name.split('_')
                
                # 确保文件名格式符合预期
                if len(parts) == 2 and parts[1].isdigit():
                    number = int(parts[1])
                    
                    # 判断数字，执行相应操作
                    if number != 99:
                        number -= 1
                    else:
                        number = 31
                    
                    # 生成新的文件名
                    new_file_name = f"{parts[0]}_{number}{ext}"
                    
                    # 获取完整的旧路径和新路径
                    old_file_path = os.path.join(subdir, file_name)
                    new_file_path = os.path.join(subdir, new_file_name)
                    
                    # 重命名文件
                    os.rename(old_file_path, new_file_path)
                    print(f"Renamed: {old_file_path} -> {new_file_path}")

# 使用你的根文件夹路径
root_folder = './IMIGUE2/train'  # 替换为你的根文件夹路径
rename_files(root_folder)

import os
def mwlines(lines, filepath):
    with open(filepath, 'w') as f:
        for line in lines:
            f.write(f"{line}\n")

def writeList(dirpath,name):
    path_train = os.path.join(dirpath, 'test')
    #path_val = os.path.join(dirpath, 'val')
    #path_test = os.path.join(dirpath, 'test')
    trainfile_list=os.listdir(path_train)
    #valfile_list=os.listdir(path_val)
    #testfile_list=os.listdir(path_test)
    train=[]
    for train_name in trainfile_list:
        traindit={}
        sp=train_name.split('_')
     
        traindit['vid_name']= train_name
        traindit['label'] = sp[2].replace('.mp4','')
        train.append(traindit)
    #val = []
    #for val_name in valfile_list:
    #    valdit={}
    #    sp=val_name.split('_')
    #    valdit['vid_name']= val_name
    #    valdit['label'] = sp[2].replace('.mp4','')
    #    val.append(valdit)
    #test = []
    #for test_name in testfile_list:
    #    testdit={}
    #    sp=test_name.split('_')
    #    testdit['vid_name']= test_name
    #    testdit['label'] = sp[2].replace('.mp4','')
    #    test.append(testdit)
     
    tmpl1 =os.path.join(path_train,'{}')
    lines1 = [(tmpl1 + ' {}').format(x['vid_name'], x['label']) for x in train]

    #tmpl2 =os.path.join(path_val,'{}')
    #lines2 = [(tmpl2 + ' {}').format(x['vid_name'], x['label']) for x in val]
     
    #3tmpl3 = os.path.join(path_test, '{}')
    #3lines3 = [(tmpl3 + ' {}').format(x['vid_name'], x['label']) for x in test]
    lines=lines1
    print(lines)
    with open(os.path.join(dirpath, name), 'w') as f:
        for line in lines:
            f.write(f"{line}\n")
writeList('./IMIGUE2', 'test.txt')
#!/usr/bin/env bash

export MASTER_PORT=$((12000 + $RANDOM % 20000))
set -x

CONFIG=$1
GPUS=$1

MKL_SERVICE_FORCE_INTEL=1 PYTHONPATH="$(dirname $0)/..":$PYTHONPATH \
CUDA_VISIBLE_DEVICES=0 /usr/bin/python $(dirname "$0")/test.py $CONFIG -C ./work_dirs_two4/epoch_5.pth --launcher pytorch ${@:3}

# Any arguments from the third one are captured by ${@:3}

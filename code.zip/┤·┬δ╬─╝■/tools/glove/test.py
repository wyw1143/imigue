import numpy as np

# 用 NumPy 加载 .npy 文件
data = np.load('tools/glove/vectors2.npy')
print(data.shape)
# 打印数组的内容
#print(data[31])
#32,300 32,512
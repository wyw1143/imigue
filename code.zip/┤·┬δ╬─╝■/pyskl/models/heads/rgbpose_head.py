import torch.nn as nn
from mmcv.cnn import normal_init
from collections import OrderedDict

from ..builder import HEADS
from .base import BaseHead
import torch
import torch
import torch.nn.functional as F
import torch.nn as nn
   

@HEADS.register_module()
class RGBPoseHead(BaseHead):
    """The classification head for Slowfast.

    Args:
        num_classes (int): Number of classes to be classified.
        in_channels (tuple[int]): Number of channels in input feature.
        loss_cls (dict): Config for building loss. Default: dict(type='CrossEntropyLoss').
        dropout (float): Probability of dropout layer. Default: 0.5.
        init_std (float): Std value for Initiation. Default: 0.01.
        kwargs (dict, optional): Any keyword argument to be used to initializ the head.
    """

    def __init__(self,
                 num_classes,
                 in_channels,
                 loss_cls=dict(type='CrossEntropyLoss'),
                 loss_cls2=dict(type='LDAM_loss'),
                 loss_components=['rgb', 'pose'],
                 loss_weights=1.,
                 dropout=0.5,
                 init_std=0.01,
                 **kwargs):

        super().__init__(num_classes, in_channels, loss_cls,loss_cls2, **kwargs)
        if isinstance(dropout, float):
            dropout = {'rgb': dropout, 'pose': dropout}
        assert isinstance(dropout, dict)

        self.dropout = dropout
        self.init_std = init_std
        self.in_channels = in_channels

        self.loss_components = loss_components
        if isinstance(loss_weights, float):
            loss_weights = [loss_weights] * len(loss_components)

        assert len(loss_weights) == len(loss_components)
        self.loss_weights = loss_weights

        self.dropout_rgb = nn.Dropout(p=self.dropout['rgb'])
        self.dropout_pose = nn.Dropout(p=self.dropout['pose'])

        self.emb_fc = nn.Linear(in_channels, 512)
        self.fc_pose = nn.Linear(in_channels, num_classes)
        self.conv_transpose = nn.ConvTranspose2d(in_channels=512, out_channels=512, kernel_size=4, stride=2, padding=1)

        hidden_dim2 = 512 // 2
        d_model = 512
        self.stadapt0_down = nn.Conv2d(d_model, d_model // 2, kernel_size=(1, 1), padding='same', groups=1)
        self.stadapt0_conv3d = nn.Conv2d(d_model // 2, d_model // 2, kernel_size=(3, 1), padding='same', groups=d_model // 2)
        self.stadapt0_up = nn.Conv2d(d_model // 2, d_model, kernel_size=(1, 1), padding='same', groups=1)

        

        ##nn.init.constant_(self.pose_adapter[2].bias, 0)

        
    def init_weights(self):
        """Initiate the parameters from scratch."""
        normal_init(self.emb_fc, std=self.init_std)
        normal_init(self.fc_pose, std=self.init_std)

    def forward(self, x):
        """Defines the computation performed at every call.

        Args:
            x (torch.Tensor): The input data.

        Returns:
            torch.Tensor: The classification scores for input samples.
        """
        #x_pose = self.avg_pool(x)
        #x_pose = x_pose.view(x_pose.size(0), -1)
        batch_size, channels, frames, height, width = x.shape
        x2 = x
        #x0 =x.mean(dim=2)  # 结果形状: (batch_size, channels, height, width)
        #x0 = x0.flatten(2) 
        x = x.permute(0, 1, 3, 4, 2).reshape(-1, frames) 
        target_frames = frames // 3 
        x = F.avg_pool1d(x.unsqueeze(1), kernel_size=3, stride=3).squeeze(1) 
        x = x.view(batch_size, channels, height, width, target_frames).permute(0, 1, 4, 2, 3) 
        x = x.reshape(batch_size * target_frames, channels, height, width) 
            #x = F.interpolate(x, size=(14, 14), mode='bilinear', align_corners=False)
        x = self.conv_transpose(x)
        x = x.view(batch_size, channels, target_frames, 14, 14)

        x = x.view(batch_size, channels, target_frames, 14 * 14) 

        x_transformed = x.permute(0, 3, 1, 2)  # 调整维度顺序 -> [12, 196, 512, 8]
        x_transformed = x_transformed.reshape(-1, channels, target_frames, 1)
        x_st = self.stadapt0_up(self.stadapt0_conv3d(self.stadapt0_down(x_transformed)))
        x_transformed = x_transformed + x_st

        x_transformed = x_transformed.reshape(batch_size, 196, channels, target_frames)  # 分离 batch 和 196
        x = x_transformed.permute(0, 2, 3, 1)

        x = x.reshape(-1, channels, 196) 

        pool = nn.AdaptiveAvgPool3d(1)

        x2 = pool(x2)
        x2 = x2.view(x2.shape[:2])
        x3 = x2
        
        emb_score=self.emb_fc(x2)#in_channel->300
        output_pose = self.dropout_pose(x2)  

            #x_pose = x_pose + x_pose2
        cls_score= self.fc_pose(output_pose)
        cls_scores = {}
        cls_scores['pose']= cls_score

        
        return cls_scores, emb_score, x, x3

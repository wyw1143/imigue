import torch
import torch.nn as nn
from mmcv.cnn import constant_init, kaiming_init
from mmcv.runner import load_checkpoint
from mmcv.utils import _BatchNorm, print_log
import numpy as np

from ...utils import get_root_logger
from ..builder import BACKBONES
from .resnet3d_slowonly import ResNet3dSlowOnly
from .vit_clip import ViT_CLIP
from . import customize_visiontransformer
from .customize_visiontransformer import Transformer, ResidualAttentionBlock

@BACKBONES.register_module()
class RGBPoseConv3D(nn.Module):
    """Slowfast backbone.

    Args:
        pretrained (str): The file path to a pretrained model.
        speed_ratio (int): Speed ratio indicating the ratio between time
            dimension of the fast and slow pathway, corresponding to the
            :math:`\\alpha` in the paper. Default: 4.
        channel_ratio (int): Reduce the channel number of fast pathway
            by ``channel_ratio``, corresponding to :math:`\\beta` in the paper.
            Default: 4.
    """
    def __init__(self,
                 pretrained=None,
                 speed_ratio=4,
                 channel_ratio=4,
                 rgb_detach=False,
                 pose_detach=False,
                 rgb_drop_path=0,
                 pose_drop_path=0,
                 rgb_pathway=dict(
                    input_resolution=224,
                    patch_size=16,
                    num_frames=8,
                    width=768,
                    layers=12,
                    heads=12,
                    drop_path_rate=0.2,
                    adapter_scale=0.5),
                 pose_pathway=dict(
                    in_channels=22,
                    base_channels=32,
                    num_stages=3,
                    out_indices=(2, ),
                    stage_blocks=(4, 6, 3),
                    conv1_stride=(1, 1),
                    pool1_stride=(1, 1),
                    inflate=(0, 1, 1),
                    spatial_strides=(2, 2, 2),
                    temporal_strides=(1, 1, 2))):

        super().__init__()
        self.pretrained = pretrained

        self.rgb_path = ViT_CLIP(**rgb_pathway)
        #pretrained_dict0 = torch.load('rgb.pth')
        #self.rgb_path.load_state_dict(pretrained_dict0, strict=False)

        self.pose_path = ResNet3dSlowOnly(**pose_pathway)
        #self.cross_transformer = Transformer(width = 768, layers = 1, heads = 12, attn_mask = None)
        self.rgb_detach = rgb_detach
        self.pose_detach = pose_detach
        assert 0 <= rgb_drop_path <= 1
        assert 0 <= pose_drop_path <= 1
        self.rgb_drop_path = rgb_drop_path
        self.pose_drop_path = pose_drop_path
        #pretrained_dict = torch.load('epoch_98.pth')['state_dict']
        #new_state_dict = {} 
        #for key in pretrained_dict.keys():
        #    new_key = key.replace('backbone.pose_path.', '')  # 去掉前缀"backbone."
        #    new_state_dict[new_key] = pretrained_dict[key]

        #self.pose_path.load_state_dict(new_state_dict, strict=False)

        #pretrained_dict = torch.load('epoch_6.pth')['state_dict']
        #new_state_dict = {} 
        #for key in pretrained_dict.keys():
       #     new_key = key.replace('backbone.model.', '')  # 去掉前缀"backbone."
        #    new_state_dict[new_key] = pretrained_dict[key]

        #self.pose_path.load_state_dict(new_state_dict, strict=False)

        #for param in self.pose_path.parameters():
        #    param.requires_grad = False


    def init_weights(self):
        """Initiate the parameters either from existing checkpoint or from
        scratch."""
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                kaiming_init(m)
            elif isinstance(m, _BatchNorm):
                constant_init(m, 1)

        if isinstance(self.pretrained, str):
            logger = get_root_logger()
            msg = f'load model from: {self.pretrained}'
            print_log(msg, logger=logger)
            load_checkpoint(self, self.pretrained, strict=True, logger=logger)
        elif self.pretrained is None:
            # Init two branch seperately.
            #self.rgb_path.init_weights()
            self.pose_path.init_weights()
        else:
            raise TypeError('pretrained must be a str or None')

    def forward(self, imgs, heatmap_imgs,training=None):
        """Defines the computation performed at every call.

        Args:
            imgs (torch.Tensor): The input data.
            heatmap_imgs (torch.Tensor): The input data.

        Returns:
            tuple[torch.Tensor]: The feature of the input
            samples extracted by the backbone.
        """

        if training:
            super().train(True)
            self.training = True

            text_encode,rgb_encode,img_encode = self.rgb_path(imgs)

            #[preds, img_encode, text_encode], [raw_pred, raw_img_encode, raw_text_encode],[icl, icl2] = self.rgb_path(imgs)
            x_pose = self.pose_path.forward(heatmap_imgs)
            return text_encode, rgb_encode, img_encode,x_pose

        else:
            super().eval()
            self.training = False
            text_encode,rgb_encode,img_encode = self.rgb_path(imgs)
            x_pose = self.pose_path.forward(heatmap_imgs)

            return text_encode, rgb_encode, img_encode,x_pose

    def train(self, mode=True):
        """Set the optimization status when training."""
        super().train(mode)
        self.training = True

    def eval(self):
        super().eval()
        self.training = False

# Copyright (c) OpenMMLab. All rights reserved.
import functools
import torch
import torch.distributed as dist
import torch.nn as nn
from torch import nn, einsum
from ..cnns.clip.model import LayerNorm, QuickGELU
from ..cnns.torch_utils import activation
import torch.nn.functional as F
from abc import ABCMeta, abstractmethod
from collections import OrderedDict
from einops import rearrange

from .. import builder


def rgetattr(obj, attr, *args):
    def _getattr(obj, attr):
        return getattr(obj, attr, *args)

    return functools.reduce(_getattr, [obj] + attr.split('.'))


class TimesAttentionBlock2(nn.Module):
    def __init__(self, d_model: int, n_head: int, attn_mask: torch.Tensor = None, T=0, temporal_modeling_type='expand_temporal_view'):
        super().__init__()
        self.T = T
        
        # type: channel_shift or expand_temporal_view
        self.attn = activation.MultiheadAttention(d_model, n_head, temporal_shift=temporal_modeling_type, T=T)
        self.ln_1 = LayerNorm(d_model)

        self.mlp = nn.Sequential(OrderedDict([
            ("c_fc", nn.Linear(d_model, d_model * 4)),
            ("gelu", QuickGELU()),
            ("c_proj", nn.Linear(d_model * 4, d_model))
        ]))

        self.ln_2 = LayerNorm(d_model)
        self.attn_mask = attn_mask

    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        l, bt, d = x.size()
        b = bt // self.T
        # x = x.view(l, b, self.T, d)
        x = x + self.attention(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
         
        return x



    def attention(self, x: torch.Tensor):
        self.attn_mask = self.attn_mask.to(dtype=x.dtype, device=x.device) if self.attn_mask is not None else None
        return self.attn(x, x, x, need_weights=False, attn_mask=self.attn_mask)[0]

    def forward(self, x):
        l, bt, d = x.size()
        b = bt // self.T
        # x = x.view(l, b, self.T, d)
        x = x + self.attention(self.ln_1(x))
         
        return x


class BaseRecognizer(nn.Module, metaclass=ABCMeta):
    """Base class for recognizers.

    All recognizers should subclass it.
    All subclass should overwrite:

    - Methods:``forward_train``, supporting to forward when training.
    - Methods:``forward_test``, supporting to forward when testing.

    Args:
        backbone (dict): Backbone modules to extract feature.
        cls_head (dict | None): Classification head to process feature. Default: None.
        train_cfg (dict): Config for training. Default: {}.
        test_cfg (dict): Config for testing. Default: {}.
    """

    def __init__(self,
                 backbone,
                 cls_head=None,
                 train_cfg=dict(),
                 test_cfg=dict()):
        super().__init__()
        # record the source of the backbone
        self.backbone = builder.build_backbone(backbone)
        self.cls_head = builder.build_head(cls_head) if cls_head else None

        if train_cfg is None:
            train_cfg = dict()
        if test_cfg is None:
            test_cfg = dict()

        assert isinstance(train_cfg, dict)
        assert isinstance(test_cfg, dict)

        self.train_cfg = train_cfg
        self.test_cfg = test_cfg
        #self.cross_transformer =TemTransformer(512,1,12)
        scale = 512 ** -0.5
        width = 512
        self.class_embedding = nn.Parameter(scale * torch.randn(width))
        heads = 8
        attn_mask = None
        layers = 1
        T = 8
        self.ln_pre2 = LayerNorm(width)
        self.ln_post2 = LayerNorm(width)
        self.ln_pre3 = LayerNorm(width)
        self.ln_post3 = LayerNorm(width)
        self.rgb_mlp = nn.Linear(512, 512)
        self.temporal_modeling_type = 'expand_temporal_view'
        self.resblocks2 = nn.Sequential(*[TimesAttentionBlock2(width, heads, attn_mask, T=T, temporal_modeling_type=self.temporal_modeling_type) for _ in range(layers)])
        self.resblocks3 = nn.Sequential(*[TimesAttentionBlock2(width, heads, attn_mask, T=T, temporal_modeling_type=None) for _ in range(layers)])
        self.conv1x1 = nn.Conv1d(in_channels=1024, out_channels=512, kernel_size=1)

        #self.proj2 = nn.Parameter(scale * torch.randn(width, 512))
        #self.class_embedding2 = nn.Parameter(scale * torch.randn(512))
        self.pose_mlp = nn.Linear(512, 32)

       # self.img_mlp = nn.Linear(768, 512)

        # max_testing_views should be int
        self.max_testing_views = test_cfg.get('max_testing_views', None)
        #self.init_weights()

    @property
    def with_cls_head(self):
        """bool: whether the recognizer has a cls_head"""
        return hasattr(self, 'cls_head') and self.cls_head is not None

    def init_weights(self):
        """Initialize the model network weights."""
        self.backbone.init_weights()
        if self.with_cls_head:
            self.cls_head.init_weights()

    def extract_feat(self, imgs,heatmap_imgs,training=None):
        """Extract features through a backbone.

        Args:
            imgs (torch.Tensor): The input images.

        Returns:
            torch.tensor: The extracted features.
        """
        text_encode,rgb_encode,img_encode,x_pose = self.backbone(imgs,heatmap_imgs,training)
        return text_encode,rgb_encode,img_encode,x_pose

    def cro_transformer(self,pose_encode,rgb_encode,img_encode):

        rgb_encode = self.rgb_mlp(rgb_encode)
        rgb_encode = rgb_encode.unsqueeze(1)#cls_token
        pose_encode = pose_encode.permute(0, 2, 1)

        x = torch.cat((rgb_encode, pose_encode), dim=1)

        
        #x = torch.cat([rgb_encode, pose_encode], dim=1)
        x = self.ln_pre2(x)
        x = x.permute(1, 0, 2) 

        for block in self.resblocks2:
            x = block(x)

        x = x.permute(1, 0, 2)
        x = self.ln_post2(x[:, 0, :])  # 形状为 (8, 512)
        #x = x @ self.proj2
        x = x / x.norm(dim=-1, keepdim=True)
        #cross_pred = self.cross_fc(cls_output)
        
        return x

    def cro_transformer2(self,pose_encode,top5_class):

        pose_encode = pose_encode.unsqueeze(1)#cls_token

        x = torch.cat((pose_encode, top5_class), dim=1)
        
        x = self.ln_pre3(x)
        x = x.permute(1, 0, 2) 

        for block in self.resblocks3:
            x = block(x)
       
        # 转回 (8, 9, 512)
        x = x.permute(1, 0, 2)
        x = self.ln_post3(x[:, 0, :])  # 形状为 (8, 512)
        #x = x @ self.proj2
        x = self.pose_mlp(x)
        
        
        return x

    def average_clip(self, cls_score):
        """Averaging class score over multiple clips.

        Using different averaging types ('score' or 'prob' or None, which defined in test_cfg) to computed the final
        averaged class score. Only called in test mode. By default, we use 'prob' mode.

        Args:
            cls_score (torch.Tensor): Class score to be averaged.

        Returns:
            torch.Tensor: Averaged class score.
        """
        assert len(cls_score.shape) == 3  # * (Batch, NumSegs, Dim)
        average_clips = self.test_cfg.get('average_clips', 'prob')
        if average_clips not in ['score', 'prob', None]:
            raise ValueError(f'{average_clips} is not supported. Supported: ["score", "prob", None]')

        if average_clips is None:
            return cls_score

        if average_clips == 'prob':
            return F.softmax(cls_score, dim=2).mean(dim=1)
        elif average_clips == 'score':
            return cls_score.mean(dim=1)

    @abstractmethod
    def forward_train(self, imgs, label, **kwargs):
        """Defines the computation performed at every call when training."""

    @abstractmethod
    def forward_test(self, imgs, **kwargs):
        """Defines the computation performed at every call when evaluation and
        testing."""

    def _parse_losses(self, losses):
        """Parse the ra w outputs (losses) of the network.

        Args:
            losses (dict): Raw output of the network, which usually contain
                losses and other necessary information.

        Returns:
            tuple[Tensor, dict]: (loss, log_vars), loss is the loss tensor
                which may be a weighted sum of all losses, log_vars contains
                all the variables to be sent to the logger.
        """
        log_vars = OrderedDict()
        for loss_name, loss_value in losses.items():
            if isinstance(loss_value, torch.Tensor):
                log_vars[loss_name] = loss_value.mean()
            elif isinstance(loss_value, list):
                log_vars[loss_name] = sum(_loss.mean() for _loss in loss_value)
            else:
                raise TypeError(f'{loss_name} is not a tensor or list of tensors')

        loss = sum(_value for _key, _value in log_vars.items() if 'loss' in _key)

        log_vars['loss'] = loss
        for loss_name, loss_value in log_vars.items():
            # reduce loss when distributed training
            if dist.is_available() and dist.is_initialized():
                loss_value = loss_value.data.clone()
                dist.all_reduce(loss_value.div_(dist.get_world_size()))
            log_vars[loss_name] = loss_value.item()

        return loss, log_vars

    def forward(self, imgs, heatmap_imgs=None,label=None, emb=None,return_loss=True, **kwargs):
        """Define the computation performed at every call."""
        if return_loss:
            if label is None:
                raise ValueError('Label should not be None.')
            return self.forward_train(imgs, heatmap_imgs, label, emb, **kwargs)

        return self.forward_test(imgs, heatmap_imgs, emb, **kwargs)
    def train_step(self, data_batch, optimizer, **kwargs):
        """The iteration step during training.

        This method defines an iteration step during training, except for the
        back propagation and optimizer updating, which are done in an optimizer
        hook. Note that in some complicated cases or models, the whole process
        including back propagation and optimizer updating is also defined in
        this method, such as GAN.

        Args:
            data_batch (dict): The output of dataloader.
            optimizer (:obj:`torch.optim.Optimizer` | dict): The optimizer of
                runner is passed to ``train_step()``. This argument is unused
                and reserved.

        Returns:
            dict: It should contain at least 3 keys: ``loss``, ``log_vars``,
                ``num_samples``.
                ``loss`` is a tensor for back propagation, which can be a
                weighted sum of multiple losses.
                ``log_vars`` contains all the variables to be sent to the
                logger.
                ``num_samples`` indicates the batch size (when the model is
                DDP, it means the batch size on each GPU), which is used for
                averaging the logs.
        """
        losses = self(**data_batch, return_loss=True)

        loss, log_vars = self._parse_losses(losses)

        outputs = dict(
            loss=loss,
            log_vars=log_vars,
            num_samples=len(next(iter(data_batch.values()))))

        return outputs

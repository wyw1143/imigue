# Copyright (c) OpenMMLab. All rights reserved.
import torch
from torch import nn
from torch.nn import functional as F

from ..builder import RECOGNIZERS
from .base import BaseRecognizer


@RECOGNIZERS.register_module()
class Recognizer3D(BaseRecognizer):
    """3D recognizer model framework."""

    def forward_train(self, imgs, heatmap_imgs, label, emb, **kwargs):
        """Defines the computation performed at every call when training."""

        assert self.with_cls_head
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        losses = dict()
        
        #pred = self.extract_feat(imgs)
        #[preds, img_encode], [raw_pred, raw_img_encode] = self.extract_feat(imgs)

        
        [preds, img_encode, text_encode], [raw_pred, raw_img_encode, raw_text_encode],[icl, icl2] = self.extract_feat(imgs)
        #cls_score = self.cls_head(pred)
        gt_label = label.squeeze()

        #loss_cls = nn.CrossEntropyLoss(preds, gt_label)
        loss_cls = self.cls_head.loss(preds, gt_label, **kwargs)

        
        loss_cls_value = loss_cls['loss_cls']  # 提取损失值

        icl_loss = (F.cross_entropy(icl, gt_label) + F.cross_entropy(icl2, gt_label)) / 2
        distillation_loss_1 = (img_encode - raw_img_encode).norm(p=2, dim=-1).mean()
        distillation_loss_2 = (text_encode - raw_text_encode).norm(p=2, dim=-1).mean()
        # 将其与 distillation_loss_1 相加
        distillation_loss = (distillation_loss_1 + distillation_loss_2) *2
        loss_cls_value = loss_cls_value + distillation_loss + icl_loss
        # 然后可以将它重新存回字典（如果需要）
        loss_cls['loss_cls'] = loss_cls_value
        losses.update(loss_cls)


        #target_text_features = text_encode[gt_label]  # [64, 512]

                # 计算 key_encode 和 target_text_features 之间的 MSE 损失
        #mse_loss = F.mse_loss(x, target_text_features)
        

        #loss_cls_value = loss_cls['loss_cls']  # 提取损失值
        #distillation_loss = (img_encode - raw_img_encode).norm(p=2, dim=-1).mean()
        #distillation_loss_2 = (text_encode - raw_text_encode).norm(p=2, dim=-1).mean()
        # 将其与 distillation_loss_1 相加
        #loss_cls_value = loss_cls_value + distillation_loss
        # 然后可以将它重新存回字典（如果需要）
        #loss_cls['loss_cls'] = loss_cls_value

        return losses

    def forward_test(self, imgs, heatmap_imgs, emb,**kwargs):
        """Defines the computation performed at every call when evaluation, testing."""
        batches = imgs.shape[0]
        num_segs = imgs.shape[1]
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])

        if self.max_testing_views is not None:
            total_views = imgs.shape[0]
            assert num_segs == total_views, (
                'max_testing_views is only compatible '
                'with batch_size == 1')
            view_ptr = 0
            feats = []
            while view_ptr < total_views:
                batch_imgs = imgs[view_ptr:view_ptr + self.max_testing_views]
                x = self.extract_feat(batch_imgs)
                feats.append(x)
                view_ptr += self.max_testing_views
            # should consider the case that feat is a tuple
            if isinstance(feats[0], tuple):
                len_tuple = len(feats[0])
                feat = [
                    torch.cat([x[i] for x in feats]) for i in range(len_tuple)
                ]
                feat = tuple(feat)
            else:
                feat = torch.cat(feats)
        else:
            feat = self.extract_feat(imgs)

        if self.test_cfg.get('feat_ext', False):
            feat_dim = len(feat[0].size()) if isinstance(feat, tuple) else len(feat.size())
            assert feat_dim in [5, 2], (
                'Got feature of unknown architecture, '
                'only 3D-CNN-like ([N, in_channels, T, H, W]), and '
                'transformer-like ([N, in_channels]) features are supported.')
            if feat_dim == 5:  # 3D-CNN architecture
                # perform spatio-temporal pooling
                avg_pool = nn.AdaptiveAvgPool3d(1)
                if isinstance(feat, tuple):
                    feat = [avg_pool(x) for x in feat]
                    # concat them
                    feat = torch.cat(feat, axis=1)
                else:
                    feat = avg_pool(feat)
                # squeeze dimensions
                feat = feat.reshape((batches, num_segs, -1))
                # temporal average pooling
                feat = feat.mean(axis=1)
            return feat.cpu().numpy()

        # should have cls_head if not extracting features
        assert self.with_cls_head
        #cls_score = self.cls_head(feat)
        cls_score = feat.reshape(batches, num_segs, feat.shape[-1])
        cls_score = self.average_clip(cls_score)
        return cls_score.cpu().numpy()

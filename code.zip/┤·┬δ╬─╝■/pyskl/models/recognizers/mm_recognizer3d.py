from ..builder import RECOGNIZERS
from .base import BaseRecognizer
from torch.nn import functional as F

import torch.nn as nn
import torch
import numpy as np

@RECOGNIZERS.register_module()
class MMRecognizer3D(BaseRecognizer):
    """MultiModality 3D recognizer model framework."""

    def forward_train(self, imgs, heatmap_imgs, emb, label, **kwargs):

        """Defines the computation performed at every call when training."""
        assert not hasattr(self, 'neck')
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        batch_size = imgs.shape[0]
        frame = imgs.shape[2]
        heatmap_imgs = heatmap_imgs.reshape((-1, ) + heatmap_imgs.shape[2:])
        losses = dict()
        text_encode,rgb_encode,img_encode, x_pose = self.extract_feat(imgs, heatmap_imgs,training=True)
        cls_scores, emb_score, pose_encode,pose_encode2 = self.cls_head(x_pose)

        top5_indices = cls_scores['pose'].argsort(dim=1, descending=True)[:, :4]  # (12, 5)
    
        top5_class = text_encode[top5_indices]
        top5_class = top5_class.mean(dim=1)
        joint_features = torch.cat([pose_encode2, top5_class], dim=1) 
        joint_features = joint_features.transpose(0, 1)  # 转置为 [1024, 96]，符合 Conv1d 的通道优先格式
        joint_features = joint_features.unsqueeze(0) 
        joint_features = self.conv1x1(joint_features)
        joint_features = joint_features.squeeze(0).transpose(0, 1)
        joint_features = self.pose_mlp(joint_features)
        #pose_output = self.cro_transformer2(pose_encode2,top5_class)
        
        cls_scores['pose'] +=joint_features




        cross_output = self.cro_transformer(pose_encode,rgb_encode,img_encode)
        gt_label = label.squeeze()

        tensor0 = torch.tensor(99.8297, device='cuda:0')

        cross_pred = tensor0 * cross_output @ text_encode.T

        cross_pred = cross_pred.reshape(batch_size, frame, -1).mean(1)

    
        cls_scores['rgb'] = cross_pred
        text_encode = text_encode[gt_label]
        loss_components = self.cls_head.loss_components
        loss_weights = self.cls_head.loss_weights
        for loss_name, weight in zip(loss_components, loss_weights):
            cls_score = cls_scores[loss_name]
            loss_cls = self.cls_head.loss(loss_name,cls_score, gt_label,emb_score,text_encode, **kwargs)
            loss_cls = {loss_name + '_' + k: v for k, v in loss_cls.items()}
            loss_cls[f'{loss_name}_loss_cls'] *= weight
            losses.update(loss_cls)

       
        return losses

    def forward_test(self, imgs, heatmap_imgs, emb, **kwargs):

        batches = imgs.shape[0]
        num_segs = imgs.shape[1]
        """Defines the computation performed at every call when evaluation and
        testing."""
        assert imgs.shape[0] == 1 and heatmap_imgs.shape[0] == 1
        assert not hasattr(self, 'neck')
        imgs = imgs.reshape((-1, ) + imgs.shape[2:])
        bz, channel_dim, clip_len, h, w = imgs.shape

        frame = imgs.shape[2]

        heatmap_imgs = heatmap_imgs.reshape((-1, ) + heatmap_imgs.shape[2:])

        text_encode,rgb_encode,img_encode, x_pose = self.extract_feat(imgs, heatmap_imgs,training=False)
        cls_scores, emb_score, pose_encode,pose_encode2 = self.cls_head(x_pose)

        top5_indices = cls_scores['pose'].argsort(dim=1, descending=True)[:, :4]  # (12, 5)
    
        top5_class = text_encode[top5_indices]
        top5_class = top5_class.mean(dim=1)
        joint_features = torch.cat([pose_encode2, top5_class], dim=1) 
        joint_features = joint_features.transpose(0, 1)  # 转置为 [1024, 96]，符合 Conv1d 的通道优先格式
        joint_features = joint_features.unsqueeze(0) 
        joint_features = self.conv1x1(joint_features)
        joint_features = joint_features.squeeze(0).transpose(0, 1)
        joint_features = self.pose_mlp(joint_features)
        #pose_output = self.cro_transformer2(pose_encode2,top5_class)
        
        cls_scores['pose'] +=joint_features
        #pose_output = self.cro_transformer2(pose_encode2,top5_class)
        
        #cls_scores['pose'] +=pose_output
        cross_output = self.cro_transformer(pose_encode,rgb_encode,img_encode)
        tensor0 = torch.tensor(99.8297, device='cuda:0')

        cross_pred = tensor0 * cross_output @ text_encode.T
        cross_pred = cross_pred.reshape(bz, clip_len, -1).mean(1)
        cls_scores['rgb'] = cross_pred

        for k in cls_scores:
            cls_score = self.average_clip(cls_scores[k][None])
            cls_scores[k] = cls_score.data.cpu().numpy()[0]
        return [cls_scores]
        

    def forward(self, imgs, heatmap_imgs, emb = None, label=None, return_loss=True, **kwargs):
        """Define the computation performed at every call."""

        if return_loss:
            if label is None:
                raise ValueError('Label should not be None.')
            return self.forward_train(imgs, heatmap_imgs, emb, label, **kwargs)

        return self.forward_test(imgs, heatmap_imgs, emb, **kwargs)
